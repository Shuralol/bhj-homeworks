const allTips = Array.from(document.querySelectorAll('.has-tooltip'));
const toolTipsActive = (e) => {
    e.preventDefault()
   
    const title = e.target.title
    const objPos = e.target.getBoundingClientRect()
    const tooltip = document.createElement('div')
    tooltip.classList.add('tooltip')
    tooltip.classList.add('tooltip_active')
    tooltip.innerText = title

    e.target.insertAdjacentHTML('afterend', `${tooltip.outerHTML}`)
    console.log(objPos)
    tooltip.style.left = objPos.x + 'px'
    tooltip.style.top = objPos.y + 'px'
}


allTips.map(item => item.addEventListener('click', toolTipsActive))


